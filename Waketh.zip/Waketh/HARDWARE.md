# Waketh — Hardware Layout for **YOUR** Components

Your kit → this layout. Every pin below matches `esp32/waketh_band.ino`,
every URL matches `hardware.py`. Physical hardware only — wire, flash, run.

| Your part | Notes |
|---|---|
| ESP32 **NodeMCU 30-pin** | all pins we need (21, 22, 4, 18) are on this board ✓ |
| **MAX30100** pulse sensor | ⚠️ different from MAX30102 — needs the oxullo library + pull-ups (below) |
| **MPU6050** motion sensor | shares the same 2 I²C wires as the MAX30100 |
| **Coin vibration motor** | the 0 dB output |
| **Transistor + 1 kΩ + diode** | motor driver (see §2c; no-transistor fallback inside) |
| **LiPo + TP4056** | power (§2d) |
| **Slide switch** | replaces the button → wired to GPIO4 (§2c) |

> **Buy/get 2 more resistors: 4.7 kΩ each (1 kΩ–10 kΩ also fine).**
> The common purple MAX30100 boards pull their I²C lines up to **1.8 V**, which
> the ESP32 cannot reliably read (it needs ≥ ~2.5 V). Two external resistors to
> 3.3 V fix this permanently — it is the #1 reason "heart rate always reads 0".

---

## 1. The whole picture

```
        ┌────────────── PC (host): python main.py ──────────────┐
        │    Scheduler (when) → Alarm (how hard) → WakeDetector │
        └────┬──────────────────────────▲───────────────────────┘
      GET /sensors (1×/s)     GET /vibrate?level=N  ·  /sync
             │      WiFi — same 2.4 GHz network       │
        ┌────▼──────────────────────▲──────────────────┴───────┐
        │              BAND (wrist)                           │
        │      ESP32 NodeMCU                                  │
        │        ├─ I²C (21/22) ── MAX30100  ← heart rate     │
        │        │              └── MPU6050   ← motion        │
        │        ├─ GPIO4  ── slide switch ── GND  ← "awake"   │
        │        └─ GPIO18 ── driver ── coin motor ← stimulus  │
        │      LiPo → TP4056 → powers everything              │
        └──────────────────────────────────────────────────────┘
```

---

## 2. Wiring, pin by pin

### 2a. The I²C bus — 2 sensors, same 4 wires

| ESP32 NodeMCU | MAX30100 | MPU6050 |
|---|---|---|
| **3V3** | VIN | VIN |
| **GND** | GND | GND |
| **GPIO21** (SDA) | SDA | SDA |
| **GPIO22** (SCL) | SCL | SCL |
| **3V3** — via **4.7 kΩ** | (pull-up on SDA line) | (same wire) |
| **3V3** — via **4.7 kΩ** | (pull-up on SCL line) | (same wire) |
| — | **INT, RD, IRD → leave unconnected** | **AD0 → GND** (I²C address 0x68) |

```
                 4.7kΩ
  ESP32 3V3 ──┬────────── SDA (GPIO21) ──┬──────── SDA pins
              │                          │
              │            4.7kΩ         │
              └────────── SCL (GPIO22) ──┴──────── SCL pins
                                              MAX30100 + MPU6050 (in parallel)

  ESP32 3V3 ── VIN of both sensors      ESP32 GND ── GND of both sensors
```

- Power the MAX30100 from **3V3, never 5V**.
- The two resistors are **in parallel with** the board's own weak pull-ups —
  that's intended; they win and pull the lines up to 3.3 V.
- No address clash: MAX30100 = 0x57, MPU6050 = 0x68.

### 2b. Slide switch (your button replacement)

| ESP32 | To |
|---|---|
| **GPIO4** | one terminal of the slide switch |
| **GND** | other terminal of the slide switch |

The code enables the internal pull-up, so: **switch OFF = open = normal sensing,
switch ON = closed = GPIO4 shorted to GND = "I'm awake" signal.**
Flipping it on instantly confirms the wake — perfect for testing (see §4).
If you'd rather use the slide switch as a *power* switch instead, put it in the
battery line (§2d) and leave GPIO4 empty — the code works either way.

### 2c. Vibration motor driver

```
ESP32 GPIO18 ─── 1 kΩ ───┤ transistor base (middle leg)
                          ├─ collector (left leg) ── motor (−)
TP4056 OUT+ ────────────── motor (+)
           │              └─ diode across motor: stripe(−) → motor(+)
TP4056 OUT− ── emitter (right leg) ── GND
```

| Detail | Value |
|---|---|
| PWM | GPIO18, 25 kHz; duty 0 / 55 / 115 / 185 / 255 = stages 0/1/2/3/4 (set in firmware) |
| Motor + | battery rail (**TP4056 OUT+**), **never** the ESP32's 3V3 pin |
| Diode | across the motor, **stripe toward motor(+)** — kills voltage spikes |

> **No transistor?** A small coin motor *can* be driven GPIO18 → motor(+) with
> motor(−) → GND for a quick bench test (add the diode!), but it draws more than
> a GPIO pin is rated for — use it to prove the concept, then add the transistor
> for the final build.

### 2d. Power

```
LiPo+ ── TP4056 B+        LiPo− ── TP4056 B−        (charging side)
TP4056 OUT+ ── ESP32 VIN  and  motor (+)             (supply side)
TP4056 OUT− ── common GND (ESP32 GND, sensors GND, transistor emitter)
```
- **Desk testing:** just plug the USB cable into the NodeMCU — no battery needed.
- **Portable:** LiPo → TP4056 as above; charge via the TP4056's USB.
- Optional power switch: insert the slide switch between `TP4056 OUT+` and `ESP32 VIN`.

---

## 3. Bring-up: from parts to working (do in this order)

### Step 1 — Arduino IDE (this programs the ESP32; Python has nothing to do with it)
1. Install **Arduino IDE 2.x** from arduino.cc.
2. *File → Preferences → Additional Boards Manager URLs* → paste:
   `https://espressif.github.io/arduino-esp32/package_esp32_index.json`
3. *Tools → Board → Boards Manager* → search **esp32** → install **"esp32 by Espressif Systems"**.
4. *Tools → Board* → select **ESP32 Dev Module**.
5. Install the two libraries:
   - *Tools → Manage Libraries* → search **MPU6050_light** → install (author **rfetick**).
   - For the MAX30100: download the ZIP →
     `https://github.com/oxullo/Arduino-MAX30100/archive/refs/heads/master.zip`
     then *Sketch → Include Library → Add .ZIP Library…* and pick that zip.
     (In the library list look for **Arduino-MAX30100** / oxullo — if you instead
     install the Library-Manager "MAX30100" by *kontakt*, my code will not compile.)
6. Open `esp32\waketh_band.ino`, edit lines 35–36 → your WiFi **name** and **password**
   (2.4 GHz only — ESP32 cannot see 5 GHz networks).
7. Plug the NodeMCU in via USB → *Tools → Port* → pick the COM port → press **→ Upload**.
8. *Tools → Serial Monitor* → set **115200**. You must see:
```
I2C scan:
  0x57  MAX30100 pulse sensor    OK
  0x68  MPU6050 motion sensor    OK
MAX30100 heart-rate sensor OK
MPU6050 motion sensor OK
....
Band online: http://waketh.local  (config.json esp32_host)
If mDNS does not resolve, use this IP instead: 192.168.1.42
```
plus a short motor buzz (self-test). ⚠️ Keep the board **still** during boot —
`mpu.calcOffsets()` calibrates then.

### Step 2 — check the band from a browser (still no Python)
On your PC, same WiFi, open:
```
http://waketh.local/sensors        → {"heart_rate":0,"motion":0.02,"button":false}
```
- put a **finger** on the MAX30100 → after ~5 s `heart_rate` starts counting (e.g. 72)
- **shake** the wristboard → `motion` climbs toward 1.0
- flip the **slide switch** → `"button":true`
- `http://waketh.local/vibrate?level=2` → motor buzzes

### Step 3 — run the Python host (this is `main.py`)
Python **never** runs inside the Arduino IDE — it runs on your PC:
- **PyCharm** (you already have the project folder): open `main.py` → press the green **▶**,
- or a terminal: `cd ...\Waketh` then `python main.py` (if Windows opens the Store, use `py main.py`).

No `pip install` needed (WiFi mode uses only the standard library).

### Step 4 — prove the whole loop
| Do this | You should see |
|---|---|
| menu `3. Show sensor data` | your live bpm + motion |
| menu `2. Test alarm` | `VIBRATION LEVEL 1/4` → motor on your wrist |
| don't move for 30 s | `VIBRATION LEVEL 2/4` (escalates only on non-response) |
| move + pulse rise **or** flip slide switch | `WAKE CONFIRMED ...` → `VIBRATION STOPPED` |
| menu `1. Set alarm` → `07:00` | `Time synced to the band at …` |
| menu `4. Show system status` | `Band link: online`, `Wake state: …` |

---

## 4. Troubleshooting (maps 1:1 to the code's failure paths)

| Symptom | Where the code tells you | Fix |
|---|---|---|
| `I2C scan: 0x57 … MISSING` | firmware boot output | SDA/SCL swapped? VIN on 3V3? **Add the two pull-up resistors** |
| `heart_rate` always `0` | `readPulse()` → `pox.getHeartRate()` returns 0 | no beat detected: press finger firmly, try again; IR LED current may need `pox.setIRLedCurrent(MAX30100_LED_CURR_7_6MA)` in firmware |
| `WARNING: MAX30100 not starting` | `pox.begin()` returned false | pull-up resistors (the 1.8 V purple-board issue) or wiring |
| `motion` always `0.00` | firmware `readIMU()` | AD0→GND, SDA→21/SCL→22; recalibrate (reset board, keep still) |
| `Band unreachable …` | `hardware.py` got no HTTP answer | same 2.4 GHz WiFi? use the IP from the serial monitor in `config.json → esp32_host` |
| Motor silent but `{"ok":true}` | command arrived, power didn't flow | transistor legs (base/collector/emitter), diode direction, motor+ on battery rail |
| Board reboots every second in serial mode | — | already handled: `hardware.py` keeps ONE serial port open |
| WiFi drops mid-alarm | `Lost contact with the band — waiting…` | loop keeps retrying; `WiFi.setAutoReconnect(true)` is set in firmware |

---

## 5. Serial mode (fallback, no WiFi)

1. `pip install pyserial`
2. `config.json` → `"hardware_mode": "serial"`, `"serial_port": "COM5"` (check Device Manager)
3. The firmware already streams one JSON line per second and accepts
   `V0..V4` (vibration) and `T<epoch>` (time) — same contract as HTTP.
