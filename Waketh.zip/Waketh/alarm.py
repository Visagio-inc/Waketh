"""Haptic escalation for the band — vibration only, 0 dB at every step.

Four stages from baseline to maximum, reached in ~90 s:
    T+0 s  level 1 (gentlest)
    T+30 s level 2
    T+60 s level 3
    T+90 s level 4 (maximum)

Intensity only climbs while the wearer shows no response — once they have
stirred, the current level is held instead of stepping up.

Every level change is pushed to the real band through the `motor` callback
(hardware.set_vibration), which is how a level on this host becomes a
physical vibration on the wrist.
"""

import time

MAX_LEVEL = 4
STEP_SECONDS = 30


class Alarm:

    def __init__(self, step_seconds=STEP_SECONDS, max_level=MAX_LEVEL, motor=None):
        self.level = 0
        self.running = False
        self.level_started_at = None
        self.step_seconds = step_seconds
        self.max_level = max_level
        self.motor = motor            # callable(level) -> True if band acked

    @property
    def at_maximum(self):
        return self.level >= self.max_level

    def _drive(self, level):
        """Send a vibration level to the band (0 = off)."""
        if self.motor is None:
            return True
        try:
            acked = bool(self.motor(level))
        except Exception:               # band unreachable — keep running
            acked = False
        if not acked:
            print(f"  ! band did not take vibration level {level} — see config.json esp32_host")
        return acked

    def start(self, level=1):
        self.level = max(1, min(level, self.max_level))
        self.running = True
        self.level_started_at = time.monotonic()
        print(f"VIBRATION LEVEL {self.level}/{self.max_level} (0 dB)")
        self._drive(self.level)

    def update(self, allow_escalation=True):
        """Advance one notch, but only on real non-response.

        When the wearer has stirred (`allow_escalation` False) the stage
        timer restarts, so a full stage of silence is required before the
        intensity climbs again.
        """
        if not self.running or self.at_maximum:
            return

        if not allow_escalation:
            self.level_started_at = time.monotonic()  # hold this level
            return

        elapsed = time.monotonic() - self.level_started_at

        if elapsed >= self.step_seconds:
            self.level += 1
            self.level_started_at = time.monotonic()
            self._drive(self.level)

            if self.at_maximum:
                print(f"VIBRATION LEVEL {self.level}/{self.max_level} — MAXIMUM ALARM LEVEL REACHED")
            else:
                print(f"VIBRATION LEVEL {self.level}/{self.max_level} (0 dB)")

    def stop(self):
        was_running = self.running
        self.level = 0
        self.running = False
        self.level_started_at = None
        if was_running:
            print("VIBRATION STOPPED")
            self._drive(0)
