/*
 * Waketh — wrist band firmware (ESP32 NodeMCU 30-pin)
 * ====================================================
 * This file is the OTHER HALF of the contract in Waketh/hardware.py:
 *
 *   GET /sensors          -> {"heart_rate":72,"motion":0.13,"button":false}
 *   GET /vibrate?level=N  -> {"ok":true}      N = 0..4  (0 = off, 4 = max)
 *   GET /sync?epoch=SEC   -> {"ok":true}                 (host -> band time)
 *
 * The band is reachable as http://waketh.local (mDNS) — no IP to type.
 * Serial fallback for config.json "hardware_mode": "serial":
 *   out: the same JSON line once per second
 *   in : "V0".."V4" = vibration level, "T<epoch>" = time sync
 *
 * YOUR COMPONENTS (wiring also in HARDWARE.md):
 *   Board   ESP32 NodeMCU 30-pin
 *   PPG     MAX30100        VIN->3V3  GND->GND  SDA->GPIO21  SCL->GPIO22
 *                         + 4.7k (or 1k) pull-up resistors: SDA->3V3, SCL->3V3
 *   IMU     MPU6050         VIN->3V3  GND->GND  SDA->GPIO21  SCL->GPIO22  AD0->GND
 *   Switch  slide switch    GPIO4 -> switch -> GND   (manual "I'm awake")
 *   Motor   coin vibration  GPIO18 -> 1k -> transistor (see HARDWARE.md)
 *
 * Required Arduino libraries (Library Manager / ZIP — see HARDWARE.md step 2):
 *   - "Arduino-MAX30100" by oxullo   (heart rate for MAX30100)
 *   - "MPU6050_light"    by rfetick  (6-axis motion)
 * Board setting: "ESP32 Dev Module"
 */

#include <WiFi.h>
#include <WebServer.h>
#include <ESPmDNS.h>
#include <Wire.h>
#include <MAX30100_PulseOximeter.h>   // oxullo's Arduino-MAX30100 library
#include <MPU6050_light.h>

// ---------- your network (edit these two lines) ----------
const char* WIFI_SSID = "YOUR_WIFI_NAME";
const char* WIFI_PASS = "YOUR_WIFI_PASSWORD";
const char* HOSTNAME  = "waketh";          // -> http://waketh.local

// ---------- pins ----------
const int BUTTON_PIN = 4;                  // slide switch: GPIO4 -> switch -> GND
const int MOTOR_PIN  = 18;                 // PWM -> 1k resistor -> transistor

// ---------- shared state ----------
WebServer server(80);
PulseOximeter pox;                         // heart-rate engine of the MAX30100
MPU6050        mpu(Wire);                  // 6-axis motion engine

volatile int   g_level     = 0;            // vibration stage 0..4
volatile float g_heartRate = 0;            // bpm, 0 = no beat yet / no finger
volatile float g_motion    = 0.0;          // 0.0 still .. 1.0 thrashing
volatile bool  g_button    = false;        // slide switch position
volatile long  g_epoch     = 0;            // time handed over by the host
volatile unsigned long g_syncMs = 0;

// motion normalisation: slowly decaying "quiet" reference of |accel|
float quietRef = 1.0;
unsigned long lastJsonMs = 0;

// ---------------------------------------------------------------- motor

void setLevel(int level) {
  level = constrain(level, 0, 4);
  static const uint8_t duty[5] = {0, 55, 115, 185, 255};  // gentle .. max
  ledcWrite(0, duty[level]);
  g_level = level;
}

// ---------------------------------------------------------------- HTTP

void handleSensors() {
  char buf[128];
  snprintf(buf, sizeof(buf),
           "{\"heart_rate\":%d,\"motion\":%.2f,\"button\":%s}",
           (int)g_heartRate, g_motion, g_button ? "true" : "false");
  server.send(200, "application/json", buf);
}

void handleVibrate() {
  if (!server.hasArg("level")) {
    server.send(400, "application/json", "{\"ok\":false}");
    return;
  }
  setLevel(server.arg("level").toInt());
  server.send(200, "application/json", "{\"ok\":true}");
}

void handleSync() {
  if (!server.hasArg("epoch")) {
    server.send(400, "application/json", "{\"ok\":false}");
    return;
  }
  g_epoch  = server.arg("epoch").toInt();
  g_syncMs = millis();
  server.send(200, "application/json", "{\"ok\":true}");
}

// ---------------------------------------------------------------- serial

void printJson() {
  char buf[128];
  snprintf(buf, sizeof(buf),
           "{\"heart_rate\":%d,\"motion\":%.2f,\"button\":%s}",
           (int)g_heartRate, g_motion, g_button ? "true" : "false");
  Serial.println(buf);
}

void handleSerialCommand() {
  if (!Serial.available()) return;
  String cmd = Serial.readStringUntil('\n');
  cmd.trim();
  if (cmd.startsWith("V")) {
    setLevel(cmd.substring(1).toInt());          // "V2" -> vibration level 2
  } else if (cmd.startsWith("T")) {
    g_epoch  = cmd.substring(1).toInt();         // "T1760000000" -> time sync
    g_syncMs = millis();
  }
}

// ---------------------------------------------------------------- sensors

void readPulse() {
  pox.update();                                  // must run as often as possible
  g_heartRate = pox.getHeartRate();              // 0 = no beat / no finger yet
}

void readIMU() {
  mpu.update();
  float ax = mpu.getAccX(), ay = mpu.getAccY(), az = mpu.getAccZ();
  float mag = sqrt(ax * ax + ay * ay + az * az);      // ~1.0 g at rest

  // deviation from rest, scaled so a real shake pegs it at 1.0
  float instant = constrain(fabs(mag - 1.0) * 4.0, 0.0, 1.0);

  // decay the quiet reference slowly so normal posture counts as "still"
  quietRef = max(0.2f, quietRef * 0.995f);
  if (instant < quietRef) quietRef = instant;

  float normalised = constrain(instant / max(quietRef, 0.15f), 0.0, 1.0);
  g_motion = g_motion * 0.7f + normalised * 0.3f;     // low-pass, reads as sustained
}

void readSwitch() {
  g_button = (digitalRead(BUTTON_PIN) == LOW);   // pull-up: switch ON = LOW
}

// ---------------------------------------------------------------- boot check

void i2cScan() {
  Serial.println("I2C scan:");
  const struct { uint8_t addr; const char* name; } devices[] = {
    {0x57, "MAX30100 pulse sensor"},
    {0x68, "MPU6050 motion sensor"}
  };
  for (const auto& d : devices) {
    Wire.beginTransmission(d.addr);
    bool found = (Wire.endTransmission() == 0);
    Serial.printf("  0x%02X  %-24s %s\n", d.addr, d.name,
                  found ? "OK" : "MISSING - check wires / pull-up resistors / 3V3");
  }
}

// ---------------------------------------------------------------- setup/loop

void setup() {
  Serial.begin(115200);
  pinMode(BUTTON_PIN, INPUT_PULLUP);           // slide switch, unconnected = HIGH = off

  // motor PWM: 25 kHz, 8-bit duty (0..255)
  ledcSetup(/*channel*/ 0, /*freq*/ 25000, /*resolution*/ 8);
  ledcAttachPin(MOTOR_PIN, 0);
  setLevel(0);

  Wire.begin(/*SDA*/ 21, /*SCL*/ 22);
  Wire.setClock(400000);
  i2cScan();                                   // prints which sensors it can see

  // MAX30100 heart-rate sensor
  if (!pox.begin()) {
    Serial.println("WARNING: MAX30100 not starting - most often missing the");
    Serial.println("         SDA->3V3 and SCL->3V3 pull-up resistors.");
  } else {
    Serial.println("MAX30100 heart-rate sensor OK");
  }
  // pox.setIRLedCurrent(MAX30100_LED_CURR_50MA);   // 50 mA is the default

  // MPU6050 motion sensor — keep the board perfectly still while it calibrates
  mpu.begin();
  mpu.calcOffsets();
  Serial.println("MPU6050 motion sensor OK");

  // WiFi + mDNS so the host can find us at http://waketh.local
  WiFi.mode(WIFI_STA);
  WiFi.setAutoReconnect(true);
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  Serial.print("Connecting to WiFi");
  while (WiFi.status() != WL_CONNECTED) { delay(300); Serial.print("."); }
  Serial.println();

  if (MDNS.begin(HOSTNAME)) {
    Serial.println("Band online: http://waketh.local  (config.json esp32_host)");
  }
  Serial.print("If mDNS does not resolve, use this IP instead: ");
  Serial.println(WiFi.localIP());

  server.on("/sensors", HTTP_GET, handleSensors);
  server.on("/vibrate", HTTP_GET, handleVibrate);
  server.on("/sync",    HTTP_GET, handleSync);
  server.begin();

  // self-test pulse so you know the motor driver works
  setLevel(1); delay(250); setLevel(0);
}

void loop() {
  readPulse();
  readIMU();
  readSwitch();
  handleSerialCommand();
  server.handleClient();
  MDNS.update();

  // one JSON heartbeat per second (used by serial mode; harmless otherwise)
  if (millis() - lastJsonMs >= 1000) {
    lastJsonMs = millis();
    printJson();
  }
  delay(5);
}
