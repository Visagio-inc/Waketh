"""Talks to the real Waketh band (esp32/waketh_band.ino) over the wire.

Default path is WiFi: the band answers at http://<esp32_host>/... where
`esp32_host` is either its mDNS name (waketh.local) or the IP the band
prints over USB serial. USB-serial is the fallback mode.

Every function is defensive: if the board is unplugged or out of range the
call returns None / False instead of crashing — that is what "connection
health" means on the architecture slide.

Wire contract with the firmware:
    GET  /sensors            -> {"heart_rate":72,"motion":0.13,"button":false}
    GET  /vibrate?level=0..4 -> {"ok":true}    (0 = off, 4 = maximum)
    GET  /sync?epoch=<unix>  -> {"ok":true}    (host -> band time sync)
Serial fallback ("hardware_mode": "serial"):
    band -> one JSON line per second (same shape as /sensors)
    host -> "V<0..4>\\n" vibration, "T<epoch>\\n" time sync
"""

import json
import time
from datetime import datetime
from pathlib import Path
from urllib.error import URLError
from urllib.request import urlopen

MAX_LEVEL = 4          # matches alarm.MAX_LEVEL
HTTP_TIMEOUT = 2
CONFIG_PATH = Path(__file__).with_name("config.json")


def _load_config():
    """config.json is optional — fall back to sane defaults if it is missing
    or malformed so the program still starts."""
    try:
        with open(CONFIG_PATH, encoding="utf-8") as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except (OSError, json.JSONDecodeError):
        return {}


CONFIG = _load_config()
MODE = CONFIG.get("hardware_mode", "wifi")     # "wifi" or "serial"


def host():
    """Where the band lives: mDNS name or IP, e.g. 'waketh.local'."""
    return str(CONFIG.get("esp32_host") or CONFIG.get("esp32_ip") or "waketh.local")


def _http_get(path):
    """GET a JSON object from the band, or None if it did not answer."""
    try:
        with urlopen(f"http://{host()}{path}", timeout=HTTP_TIMEOUT) as resp:
            body = resp.read().decode("utf-8", errors="replace")
    except (URLError, OSError, ValueError):
        return None
    try:
        data = json.loads(body)
    except ValueError:
        return None
    return data if isinstance(data, dict) else None


# ---------------------------------------------------------------- sensors

def get_sensor_data():
    """One sample from the band.

    Always returns:
    {
        "heart_rate": int,
        "motion_detected": float,
        "button": bool
    }
    Returns None if the board did not respond this cycle —
    callers must handle that.
    """
    if MODE == "wifi":
        data = _http_get("/sensors")
        return None if data is None else _normalise(data)
    elif MODE == "serial":
        return _read_serial()
    else:
        raise ValueError(f"Unknown hardware_mode: {MODE}")


def _normalise(data):
    return {
        "heart_rate": int(data.get("heart_rate", 0)),
        "motion_detected": float(data.get("motion", data.get("motion_detected", 0.0))),
        "button": bool(data.get("button", False))
    }


# ------------------------------------------------------------ actuator

def set_vibration(level):
    """Drive the band's haptic motor. 0 = off, 1..4 = escalation stages.
    Returns True when the band acknowledged the command."""
    level = max(0, min(int(level), MAX_LEVEL))
    if MODE == "wifi":
        return _http_get(f"/vibrate?level={level}") is not None
    elif MODE == "serial":
        return _serial_write(f"V{level}\n")
    else:
        raise ValueError(f"Unknown hardware_mode: {MODE}")


def sync_time(when=None):
    """WiFi time sync: hand the current clock to the band. Returns True on ack."""
    epoch = int((when or datetime.now()).timestamp())
    if MODE == "wifi":
        return _http_get(f"/sync?epoch={epoch}") is not None
    elif MODE == "serial":
        return _serial_write(f"T{epoch}\n")
    else:
        raise ValueError(f"Unknown hardware_mode: {MODE}")


# ------------------------------------------------------------ serial mode

_serial_port = None
_serial_mod = None


def _open_serial():
    """Keep ONE port handle open. Reopening it every second would toggle the
    ESP32's DTR/RTS lines and reboot the board each cycle."""
    global _serial_port, _serial_mod
    if _serial_port is not None and getattr(_serial_port, "is_open", False):
        return _serial_port

    try:
        import serial
    except ImportError:
        print("pyserial is not installed — run: pip install pyserial")
        return None
    _serial_mod = serial

    try:
        port = serial.Serial(CONFIG.get("serial_port", "COM3"),
                             int(CONFIG.get("serial_baud", 115200)),
                             timeout=1)
        time.sleep(0.3)                 # ESP32 reboots when the port opens
        port.reset_input_buffer()
        _serial_port = port
        return port
    except (serial.SerialException, OSError):
        _serial_port = None
        return None


def _close_serial():
    global _serial_port
    if _serial_port is not None:
        try:
            _serial_port.close()
        except OSError:
            pass
    _serial_port = None


def _read_serial():
    port = _open_serial()
    if port is None:
        return None
    try:
        for _ in range(3):              # skip boot text, want a JSON line
            line = port.readline().decode("utf-8", errors="replace").strip()
            if line.startswith("{"):
                return _normalise(json.loads(line))
    except (OSError, ValueError):
        _close_serial()
    return None


def _serial_write(payload):
    port = _open_serial()
    if port is None:
        return False
    try:
        port.write(payload.encode("ascii"))
        return True
    except OSError:
        _close_serial()
        return False
