"""Waketh host console — a wearable biometric wake system.

Everything here talks to the REAL band (esp32/waketh_band.ino) over WiFi.
Architecture (slide 7):

    Scheduler    keeps the wake time, WiFi-syncs it to the band, tracks link
    Alarm        drives the band's haptic motor — 4 stages, ~90 s to max, 0 dB
    WakeDetector decision loop: motion + pulse decide when the wake is real

Flow (slide 10): time arrives -> band vibrates gently -> sensors listen ->
no response means one notch up -> sustained motion + pulse shift means the
wearer is up and the band goes still.
"""

import time
from datetime import datetime

import hardware
from alarm import Alarm
from scheduler import Scheduler
from wake_logic import WakeDetector

scheduler = Scheduler(band_id=hardware.CONFIG.get("band_id", "waketh-01"))
alarm = Alarm(motor=hardware.set_vibration)   # alarm levels become real vibrations
detector = WakeDetector()


def offline_help():
    return (
        "Band unreachable — checklist:\n"
        "  1. Band powered (LiPo or USB) and its LED alive\n"
        "  2. PC and ESP32 on the SAME 2.4 GHz WiFi network\n"
        f"  3. config.json esp32_host matches the IP the band prints over "
        f"USB serial (currently: {hardware.host()}, mode: {hardware.MODE})"
    )


def read_sensors():
    """One sample from the band (None if it did not answer)."""
    return hardware.get_sensor_data()


def show_menu():
    print()
    print("========== WAKETH ==========")
    print("1. Set alarm")
    print("2. Test alarm")
    print("3. Show sensor data")
    print("4. Show system status")
    print("5. Stop alarm")
    print("6. Exit")


def set_alarm():
    raw = input("Wake time (HH:MM, 24h): ").strip()
    try:
        hour_str, minute_str = raw.split(":")
        hour, minute = int(hour_str), int(minute_str)
    except ValueError:
        print("Please enter the time as HH:MM, e.g. 06:30")
        return

    try:
        scheduler.set_alarm(hour, minute)
    except ValueError as err:
        print(err)
        return

    print(f"Wake time set for {hour:02d}:{minute:02d} on band {scheduler.band_id}")

    if hardware.sync_time():
        scheduler.record_sync(True)
        print(f"Time synced to the band at {scheduler.last_sync:%H:%M:%S}")
    else:
        scheduler.record_sync(False)
        print("Warning: schedule stored locally, but the band did not answer.")
        print(offline_help())


def show_sensor_data():
    data = read_sensors()
    scheduler.record_sync(data is not None)
    if data is None:
        print(offline_help())
        return
    print(f" heart rate : {data['heart_rate']} bpm")
    print(f" motion     : {data['motion_detected']:.2f}")
    print(f" button     : {'pressed' if data['button'] else 'idle'}")


def show_status():
    if scheduler.last_sync:
        sync = f"{scheduler.last_sync:%H:%M:%S}"
    else:
        sync = "never"

    if alarm.running:
        alarm_state = f"RUNNING — vibration level {alarm.level}/{alarm.max_level}"
    else:
        alarm_state = "idle"

    print()
    print("---------- SYSTEM STATUS ----------")
    print(f" Sensor mode : {hardware.MODE}")
    print(f" Band host   : {hardware.host()}")
    print(f" Scheduler   : {scheduler.describe()}")
    print(f" Band link   : {'online' if scheduler.connected else 'offline'} (last contact {sync})")
    print(f" Alarm       : {alarm_state}")
    print(f" Wake state  : {detector.state}")
    print(f" Escalation  : {alarm.max_level} stages, {alarm.step_seconds}s each "
          f"(max at T+{alarm.step_seconds * (alarm.max_level - 1)}s, 0 dB always)")


def run_wake_cycle():
    """The closed loop: vibrate, listen, escalate only on real non-response,
    stop the moment the wake is confirmed."""
    print()
    print("Wake cycle started — vibration only, 0 dB.")
    print("Press Ctrl+C to return to the menu.")

    data = read_sensors()
    retries = 0
    while data is None and retries < 3:
        print("Waiting for the band to answer...")
        time.sleep(2)
        retries += 1
        data = read_sensors()
    if data is None:
        scheduler.record_sync(False)
        print("Band did not respond — wake cycle aborted.")
        print(offline_help())
        return

    scheduler.record_sync(hardware.sync_time())
    detector.start_assessment(data["heart_rate"])
    alarm.start()
    print(f"Baseline pulse: {data['heart_rate']} bpm | "
          f"escalating every {alarm.step_seconds}s unless the wearer stirs")

    last_state = detector.state
    was_online = True

    try:
        while alarm.running:
            time.sleep(1)

            data = read_sensors()
            if data is None:
                scheduler.record_sync(False)
                if was_online:
                    print("Lost contact with the band — waiting for it to come back...")
                    was_online = False
                continue
            scheduler.record_sync(True)
            was_online = True

            detector.update(data)

            if detector.is_awake:
                alarm.stop()
                if data["button"]:
                    reason = "button press"
                else:
                    reason = f"sustained motion + pulse at {data['heart_rate']} bpm"
                print(f"WAKE CONFIRMED ({reason}) — band is still. 0 dB throughout.")
            else:
                alarm.update(allow_escalation=not detector.has_stirred)

                if detector.state != last_state:
                    if detector.state == "PROBABLE_WAKE":
                        print("Wearer stirred — holding intensity at the current level.")
                    last_state = detector.state

    except KeyboardInterrupt:
        alarm.stop()
        detector.reset()
        print("Wake cycle stopped.")


def main():
    print("Waketh host — wearable biometric wake system.")

    while True:

        if scheduler.should_trigger(datetime.now()):
            print()
            print("Scheduled wake time reached.")
            run_wake_cycle()

        show_menu()

        try:
            raw = input("Choose: ").strip()
            choice = int(raw)
        except ValueError:
            print("Enter a number from 1 to 6")
            continue
        except EOFError:
            print("\nExiting Waketh...")
            alarm.stop()
            break

        if choice == 1:
            set_alarm()

        elif choice == 2:
            run_wake_cycle()

        elif choice == 3:
            show_sensor_data()

        elif choice == 4:
            show_status()

        elif choice == 5:
            if alarm.running:
                alarm.stop()
                detector.reset()
            else:
                print("No alarm is running.")

        elif choice == 6:
            alarm.stop()
            print("Exiting Waketh...")
            break

        else:
            print("Unknown option")


if __name__ == "__main__":
    main()
