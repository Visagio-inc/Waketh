"""Host-side scheduler (architecture slide, part 01).

Keeps each person's wake time, knows which band it belongs to, tracks the
WiFi time-sync / connection health for that band, and fires once at the
set minute.
"""

from datetime import datetime


class Scheduler:

    def __init__(self, band_id="waketh-01"):
        self.band_id = band_id
        self.alarm_time = None
        self.triggered_date = None
        self.connected = False
        self.last_sync = None

    @property
    def armed(self):
        return self.alarm_time is not None

    def set_alarm(self, hour, minute, band_id=None):
        if not (0 <= hour <= 23 and 0 <= minute <= 59):
            raise ValueError(f"Invalid wake time: {hour:02d}:{minute:02d}")
        if band_id:
            self.band_id = band_id
        self.alarm_time = (hour, minute)
        self.triggered_date = None  # re-arm immediately

    def record_sync(self, success=True, when=None):
        """WiFi time-sync with the band; doubles as connection health.
        `last_sync` only advances on a SUCCESSFUL exchange, so it always
        shows the last real contact with the band."""
        self.connected = bool(success)
        if success:
            self.last_sync = when or datetime.now()
        return self.connected

    def should_trigger(self, now):
        """True exactly once during the scheduled minute, every day."""
        if self.alarm_time is None:
            return False

        alarm_hour, alarm_minute = self.alarm_time

        if now.hour == alarm_hour and now.minute == alarm_minute:
            if now.date() != self.triggered_date:
                self.triggered_date = now.date()
                return True

        return False

    def clear(self):
        self.alarm_time = None
        self.triggered_date = None

    def describe(self):
        if self.alarm_time is None:
            return "no alarm set"
        hour, minute = self.alarm_time
        return f"armed for {hour:02d}:{minute:02d} (band {self.band_id})"
