"""Decision loop that runs on the band (architecture slide, part 03).

Reads motion and pulse together and decides, moment to moment, whether the
wearer is actually awake:

    IDLE -> ASSESSING -> PROBABLE_WAKE -> CONFIRMED_AWAKE

  * PROBABLE_WAKE   any single cue (button, pulse shift or sustained motion)
                    — enough to hold the escalation, not enough to stop it.
  * CONFIRMED_AWAKE the button, or a pulse shift *together with* sustained
                    motion — the band goes still and reports back.

Escalation is allowed to continue only while the wearer has not stirred
(see Alarm.update), so the intensity climbs on real non-response only.
"""

import time


class WakeDetector:

    HEART_RATE_RISE = 5            # bpm above baseline that counts as stirring
    MOTION_THRESHOLD = 0.8         # "meaningful" motion on the 6-axis sensor
    SUSTAINED_MOTION_SECONDS = 20  # movement must be held, not just twitched

    def __init__(self):
        self.state = "IDLE"
        self.starting_heart_rate = None
        self.motion_start_time = None
        self.motion_duration = 0

    @property
    def is_awake(self):
        return self.state == "CONFIRMED_AWAKE"

    @property
    def has_stirred(self):
        """True once the wearer has shown any sign of waking."""
        return self.state in ("PROBABLE_WAKE", "CONFIRMED_AWAKE")

    def start_assessment(self, heart_rate):
        self.state = "ASSESSING"
        self.starting_heart_rate = heart_rate
        self.motion_start_time = None
        self.motion_duration = 0

    def reset(self):
        self.state = "IDLE"
        self.starting_heart_rate = None
        self.motion_start_time = None
        self.motion_duration = 0

    def update(self, sensor_data):
        if self.state in ("IDLE", "CONFIRMED_AWAKE"):
            return  # nothing to assess, or the wake is already confirmed

        if self.starting_heart_rate is None:
            return

        heart_rate = sensor_data.get("heart_rate", 0)
        motion = float(sensor_data.get("motion_detected", 0.0))
        button = bool(sensor_data.get("button", False))

        heart_rate_increased = heart_rate >= self.starting_heart_rate + self.HEART_RATE_RISE

        # sustained motion: > threshold, held for SUSTAINED_MOTION_SECONDS
        if motion > self.MOTION_THRESHOLD:
            if self.motion_start_time is None:
                self.motion_start_time = time.monotonic()
            self.motion_duration = time.monotonic() - self.motion_start_time
        else:
            self.motion_start_time = None
            self.motion_duration = 0

        sustained_motion = self.motion_duration >= self.SUSTAINED_MOTION_SECONDS

        # Confirmed: manual button press, or pulse shift + sustained movement together
        if button or (heart_rate_increased and sustained_motion):
            self.state = "CONFIRMED_AWAKE"
            return

        # Probable: a single cue — hold intensity, keep listening
        if button or heart_rate_increased or sustained_motion:
            self.state = "PROBABLE_WAKE"


if __name__ == "__main__":
    detector = WakeDetector()

    print("Initial state:", detector.state)

    detector.start_assessment(72)
    print("New state:", detector.state)

    detector.update({"heart_rate": 73, "motion_detected": 0.1, "button": False})
    print("After quiet sample:", detector.state)
